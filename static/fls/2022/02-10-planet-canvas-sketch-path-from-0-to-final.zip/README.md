# threejs-3d-planet-variants
Варианты планеты. От 0 до полноценной версии.

Файды для cavas-sketch (https://github.com/mattdesl/canvas-sketch)

Для запуска у Вас должен быть установлен вышеупомянутый пакет.
Используйте команду

`canvas-sketch "имя файла"`

в папке, где будут лежать эти файлы и модули nodejs

### Если Вы новичёк.
Выполните установку nodejs
затем скачайте архив. распакуйте его. войдите в консоль (терминал), вполните команду

``
cd [путь/к/папке, которую Вы распаковали]
``
затем в терминале
`npm install`

затем
`canvas-sketch "имя файла, который хотите запустить"`

### Live view
https://codepen.io/inverser/pen/QWaLqPm

### Docs (lang: RU)
https://three.inverser.pro

Nice day!
