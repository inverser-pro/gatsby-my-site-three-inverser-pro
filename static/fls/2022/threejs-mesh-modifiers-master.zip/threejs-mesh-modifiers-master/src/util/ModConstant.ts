export class ModConstant {
  public static NONE: number = 0;

  public static X: number = 1;
  public static Y: number = 2;
  public static Z: number = 4;

  public static LEFT: number = -1;
  public static RIGHT: number = 1;
}
